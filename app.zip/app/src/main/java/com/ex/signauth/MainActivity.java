package com.ex.signauth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setStatusBarColor();
        firebaseAuth = FirebaseAuth.getInstance();
        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.password);
        Button login = findViewById(R.id.login);
        Button register = findViewById(R.id.register);

        register.setOnClickListener(v -> {
            String getEmail = email.getText().toString();
            String getPassword = password.getText().toString();
            firebaseAuth.createUserWithEmailAndPassword(getEmail, getPassword)
                    .addOnSuccessListener(authResult -> Toast.makeText(MainActivity.this,"User Account Created", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e -> Toast.makeText(MainActivity.this,""+e.getMessage(),Toast.LENGTH_SHORT).show());
        });
        login.setOnClickListener(v -> {
            String getEmail = email.getText().toString();
            String getPassword = password.getText().toString();
            firebaseAuth.signInWithEmailAndPassword(getEmail, getPassword)
           // .addOnSuccessListener(authResult -> Toast.makeText(MainActivity.this,"Welcome User", Toast.LENGTH_SHORT).show())
                    .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                           //Toast.makeText(MainActivity.this,"Welcome", Toast.LENGTH_SHORT).show();
                           Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                           startActivity(intent);
                        }
                    })
                    .addOnFailureListener(e -> Toast.makeText(MainActivity.this,""+e.getMessage(), Toast.LENGTH_SHORT).show());
        });
    }

    private void setStatusBarColor() {
    }
}