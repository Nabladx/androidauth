package com.ex.signauth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;

public class AuthActivity extends AppCompatActivity {


    private FirebaseAuth mFirebaseAuth;
    public static final String TAG = "GoogleSignIn";
    TextView tvUserName;
    TextView tvUserEmail;
   // TextView tvUserPassword;
    ImageView userImageView;
    Button btnSignOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);

        tvUserName = findViewById(R.id.userName);
        tvUserEmail = findViewById(R.id.userEmail);
      //  tvUserPassword = findViewById(R.id.userPassword);
        userImageView = findViewById(R.id.userImage);
        btnSignOut = findViewById(R.id.btnLogout);
        mFirebaseAuth = FirebaseAuth.getInstance();

        SharedPreferences preferences = this.getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String userName = preferences.getString("username","");
        String userEmail = preferences.getString("useremail", "");
     //   String userPassword = preferences.getString("userpassword","");
        String userImageUrl = preferences.getString("userPhoto","");

        tvUserName.setText(userName);
        tvUserEmail.setText(userEmail);
    //    tvUserPassword.setText(userPassword);
        Glide.with(this).load(userImageUrl).into(userImageView);
        btnSignOut.setOnClickListener(view -> {
           FirebaseAuth.getInstance().signOut();
            FirebaseAuth.getInstance().signOut();
            goToProfileActivity();
        });
    }

    private void goToProfileActivity() {
        startActivity(new Intent(AuthActivity.this, ProfileActivity.class));
    }
}